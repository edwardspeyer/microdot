#!/usr/bin/env bash

set -e

"$(dirname "$0")/npm_install.sh" vscode-json-language-server vscode-langservers-extracted
