# data

## catalog.json

JSON Schemas

https://raw.githubusercontent.com/SchemaStore/schemastore/master/src/api/json/catalog.json
